import { Component } from '@angular/core';

@Component({
  selector: 'login-page',
  templateUrl: './login.html',
  styleUrls: ['./login.scss']
})
export class LoginPage {

	public email:any;
	public password:any; 

	login() {
		
	}

}
