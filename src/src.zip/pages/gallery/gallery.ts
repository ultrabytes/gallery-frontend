import { Component } from '@angular/core';

@Component({
  selector: 'gallery-page',
  templateUrl: './gallery.html',
  styleUrls: ['./gallery.scss']
})
export class GalleryPage {

	public email:any;
	public password:any; 

	upload() {
		
	}

}
