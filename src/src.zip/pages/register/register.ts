import { Component } from '@angular/core';

@Component({
  selector: 'register-page',
  templateUrl: './register.html',
  styleUrls: ['./register.scss']
})
export class RegisterPage {

	public model:any = {};

	register() {
		console.log(this.model);
	}

}
